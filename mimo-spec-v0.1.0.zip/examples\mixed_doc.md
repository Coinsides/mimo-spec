# Mixed Sample

This document contains text plus a small table.

| item | value |
|---|---|
| alpha | 1 |
| beta | 2 |

End of document.
