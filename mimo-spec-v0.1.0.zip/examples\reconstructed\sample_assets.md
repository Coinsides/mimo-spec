# Assets Summary
- image_001.mimo: Image file: sample.jpg; size=12345 bytes; mime=image/jpeg.
- audio_001.mimo: Audio file: sample.m4a; transcript: "Hello world".
